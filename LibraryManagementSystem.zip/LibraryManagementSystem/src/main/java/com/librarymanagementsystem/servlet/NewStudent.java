package com.librarymanagementsystem.servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.librarymanagementsystem.DTO.StudentDto;
import com.librarymanagementsystem.Dao.StudentDao;
import com.librarymanagementsystem.entity.Student;

@WebServlet("/NewStudent")
public class NewStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public NewStudent() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name = request.getParameter("username");
		String sid = request.getParameter("studentId");
		String pass = request.getParameter("password");
		String email = request.getParameter("email");
		String mobNo = request.getParameter("mobNo");
		String branch = request.getParameter("branch");

		Student se = new Student(name, sid,pass,email,mobNo, branch);
		StudentDao sdao = new StudentDao();
		StudentDto sdto =sdao.registerStudent(se);

		request.setAttribute("ddto", sdto);
		RequestDispatcher rd = request.getRequestDispatcher("NewStudent.jsp");
		rd.forward(request, response);
	}
}
