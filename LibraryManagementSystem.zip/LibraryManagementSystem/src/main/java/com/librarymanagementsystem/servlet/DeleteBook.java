package com.librarymanagementsystem.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.librarymanagementsystem.DTO.GenDTO;
import com.librarymanagementsystem.Dao.BookDao;

@WebServlet("/DeleteBook")
public class DeleteBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public DeleteBook() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String idStr = request.getParameter("id");

		if (idStr == null || idStr.isEmpty()) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid or missing book ID.");
			return;
		}

		try {
			int id = Integer.parseInt(idStr);
			BookDao bdao = new BookDao();
			GenDTO result = bdao.deleteByPk(id);

			if (result.isStatus()) {
				response.sendRedirect("Book.jsp");
			} else {
				request.setAttribute("errorMsg", result.getMsg());
				request.getRequestDispatcher("Book.jsp").forward(request, response);
			}
		} catch (NumberFormatException e) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid book ID format.");
		}
	}

}
