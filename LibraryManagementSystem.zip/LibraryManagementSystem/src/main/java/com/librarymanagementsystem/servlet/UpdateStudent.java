package com.librarymanagementsystem.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.librarymanagementsystem.DTO.GenDTO;
import com.librarymanagementsystem.Dao.BookDao;
import com.librarymanagementsystem.entity.Book;

/**
 * Servlet implementation class UpdateStudent
 */
@WebServlet("/UpdateStudent")
public class UpdateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateStudent() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String bName = request.getParameter("bookname");
		String author = request.getParameter("author");
		String publisher = request.getParameter("publisher");
		String isbn = request.getParameter("isbn");
		String category = request.getParameter("category");

		String noofcopy = request.getParameter("noOfCopy");
		int noofcopy1 = 0;
		if (noofcopy != null && !noofcopy.isEmpty()) {
			try {
				noofcopy1 = Integer.parseInt(noofcopy);
			} catch (NumberFormatException e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid number of copies.");
				return;
			}
		}

		String did = request.getParameter("id");
		int did1 = 0;
		if (did != null && !did.isEmpty()) {
			try {
				did1 = Integer.parseInt(did);
			} catch (NumberFormatException e) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid ID.");
				return;
			}
		}

		Book de = new Book(did1, bName, author, publisher, isbn, category, noofcopy1);

		BookDao sdao = new BookDao();
		GenDTO gdto = sdao.updateByPk(did1, de);

		request.setAttribute("gdto", gdto);
		RequestDispatcher rd = request.getRequestDispatcher("NewStudent.jsp");
		rd.forward(request, response);

	}

}
