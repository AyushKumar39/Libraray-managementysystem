package com.librarymanagementsystem.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

 
@WebServlet("/AdminSignup")
public class AdminSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
     
    public AdminSignup() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		String email = request.getParameter("email");
		String password = request.getParameter("password");

		HttpSession session = request.getSession();
		RequestDispatcher dispatcher = null;

		try {
			PrintWriter out = response.getWriter();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/library_management_system?useSSL=false", "root", "ayush396796");
			PreparedStatement ps = con.prepareStatement("select * from admin where aemail=? and apwd=?");
			ps.setString(1, email);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				session.setAttribute("username", rs.getString("aname"));
				dispatcher = request.getRequestDispatcher("Book.jsp");
				dispatcher.forward(request, response);
			} else {
				out.println("<font color=red size=18>login Failed !!<br>");
				out.println("<a href=StudentSignup.jsp>Try Again !!</a>");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	
	}

}
