package com.librarymanagementsystem.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.librarymanagementsystem.DTO.BookDto;
import com.librarymanagementsystem.Dao.BookDao;
import com.librarymanagementsystem.entity.Book;

@WebServlet("/AddBook")
public class AddBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AddBook() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("bookname");
		String author = request.getParameter("author");
		String publisher = request.getParameter("publisher");
		String isbn = request.getParameter("isbn");
		String category = request.getParameter("category");
		int copy =Integer.parseInt(request.getParameter("noOfCopy"));

		Book be = new Book(username, author, publisher, isbn, category, copy);
		BookDao bdao = new BookDao();
		BookDto sdto = bdao.registerBook(be);

		request.setAttribute("sdto", sdto);
		RequestDispatcher rd = request.getRequestDispatcher("Book.jsp");
		rd.forward(request, response);

	}

}
