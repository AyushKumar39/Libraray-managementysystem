package com.librarymanagementsystem.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.librarymanagementsystem.Dao.BookDao;

@WebServlet("/ReturnBook")
public class ReturnBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ReturnBook() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
 
		int lendId = Integer.parseInt(request.getParameter("lendId"));
		int bookId = Integer.parseInt(request.getParameter("bookId"));
		String returnedDateString = request.getParameter("returneddate");

 		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate returnedDate = LocalDate.parse(returnedDateString, formatter);

 		int result = BookDao.returnBook(lendId, bookId, returnedDate);
		PrintWriter out = response.getWriter();

		if (result > 0) {
 			RequestDispatcher rd = request.getRequestDispatcher("ReturnedBook.jsp");
			rd.forward(request, response);
		} else {

			out.println("<font color=red size=18>Return Failed! Book not found.<br>");
			out.println("<a href='issueBook.jsp'>Try Again</a>");
		}
	}
}
