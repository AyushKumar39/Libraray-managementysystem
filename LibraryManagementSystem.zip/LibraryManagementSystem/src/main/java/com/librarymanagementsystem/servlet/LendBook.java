package com.librarymanagementsystem.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.librarymanagementsystem.Dao.BookDao;
import com.librarymanagementsystem.entity.Lend;

@WebServlet("/LendBook")
public class LendBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LendBook() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
 	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("bookId"));
		int sid = Integer.parseInt(request.getParameter("studentId"));

		Lend lend = new Lend();
		lend.setId(id);
		lend.setSid(sid);
		lend.setIssueDate(new Date());

		Lend lend1 = new Lend(id, sid);
		int i = BookDao.issueBook(lend1);
		PrintWriter out = response.getWriter();
		if (i > 0) {
			RequestDispatcher rd = request.getRequestDispatcher("StudentDashBoard.jsp");
			rd.forward(request, response);
		} else {
			out.println("<font color=red size=18>Not Found Failed !!<br>");
			out.println("<a href=issueBook.jsp>Try Again !!</a>");
		
		}
	}

}
