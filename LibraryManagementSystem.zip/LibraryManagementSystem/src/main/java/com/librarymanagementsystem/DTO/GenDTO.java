package com.librarymanagementsystem.DTO;

import java.io.Serializable;

public class GenDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private boolean status;
	private String msg;
	private long rowCount;
	private Exception ex;

	public GenDTO(boolean status, String msg, long rowCount, Exception ex) {
		super();
		this.status = status;
		this.msg = msg;
		this.rowCount = rowCount;
		this.ex = ex;
	}

	public GenDTO(boolean status, String msg, Exception ex) {
		super();
		this.status = status;
		this.msg = msg;
		this.ex = ex;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isStatus() {
		return status;
	}

	public String getMsg() {
		return msg;
	}

	public long getRowCount() {
		return rowCount;
	}

	public Exception getEx() {
		return ex;
	}





}
