package com.librarymanagementsystem.DTO;

import com.librarymanagementsystem.entity.Student;

public class StudentDto extends GenDTO{
	private Student student;

	public StudentDto(boolean status, String msg, long rowCount, Exception ex,Student student) {
		super(status, msg, rowCount, ex);
		this.student=student;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "StudentDto [student=" + student + "]";
	}
	

}
