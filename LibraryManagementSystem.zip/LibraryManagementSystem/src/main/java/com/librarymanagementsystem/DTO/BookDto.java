package com.librarymanagementsystem.DTO;

import com.librarymanagementsystem.entity.Book;

public class BookDto extends GenDTO {
	
	private Book book;
	
	public BookDto(boolean status, String msg, long rowCount, Exception ex,Book book) {
		super(status, msg, rowCount, ex);
		this.book=book;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	@Override
	public String toString() {
		return "BookDto [book=" + book + "]";
	}
	
}
