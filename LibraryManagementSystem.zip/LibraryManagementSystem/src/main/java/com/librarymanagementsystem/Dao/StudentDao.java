package com.librarymanagementsystem.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.librarymanagementsystem.DTO.GenDTO;
import com.librarymanagementsystem.DTO.StudentDto;
import com.librarymanagementsystem.db.dbConnection;
import com.librarymanagementsystem.entity.Student;

public class StudentDao {

	// ----------------------Insert Method ----------------------------

	public StudentDto registerStudent(Student student) {
		StudentDto dDto = null;

		String sql = "insert into student (sname,sId,spwd,semail,smobNo,branch)values(?,?,?,?,?,?)";

		try (Connection con = dbConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, student.getName());
			ps.setString(2, student.getStudentId());
			ps.setString(3, student.getPassword());
			ps.setString(4, student.getEmail());
			ps.setString(5, student.getMobNo());
			ps.setString(6, student.getBranch());

			ps.executeUpdate();

		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();

		}

		return dDto;
	}

	// ------------------SELECT ALL METHOD--------------------

	public List<Student> getAllStudent(Student se) {
		List<Student> list = new ArrayList<Student>();
		Connection con = null;

		try {

			con = dbConnection.getConnection();
			String sql = "SELECT * FROM student ORDER BY id DESC";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Student s = new Student();
				s.setId(rs.getInt("id"));
				s.setName(rs.getString("sname"));
				s.setStudentId(rs.getString("sId"));
				s.setPassword(rs.getString("spwd"));
				s.setEmail(rs.getString("semail"));
				s.setMobNo(rs.getString("smobNo"));
				s.setBranch(rs.getString("Branch"));

				list.add(s);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {

			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}

	 

	// ---------------- UPDATE METHOD ------------------------
        
        
        public GenDTO updateByPk(Student se, int id) {
            String source = "student------------>Update ";
            System.out.println(source + "Invoke");
            GenDTO gdto = null;

            String sql = "UPDATE student SET sname=?, sId=?, spwd=?, semail=?, smobNo=?, branch=? WHERE id=?";

            try (Connection con = dbConnection.getConnection();
                 PreparedStatement psmt = con.prepareStatement(sql)) {

 
                psmt.setString(1, se.getName());
                psmt.setString(2, se.getStudentId());
                psmt.setString(3, se.getPassword());
                psmt.setString(4, se.getEmail());
                psmt.setString(5, se.getMobNo());
                psmt.setString(6, se.getBranch());
                psmt.setInt(7, id);  

                 int rowsAffected = psmt.executeUpdate();

                if (rowsAffected == 0) {
                    System.out.println(source + "Record not found for given id");
                    gdto = new GenDTO(false, "Record not found", null);
                } else {
                    System.out.println(source + "Record updated successfully");
                    gdto = new GenDTO(true, "Record updated", null);
                }

            } catch (ClassNotFoundException | SQLException ex) {
                ex.printStackTrace();
                gdto = new GenDTO(false, ex.getMessage(), ex);
            }

            return gdto;
        }

    	 //---------------------- DELETE METHOD -------------------------------------  
       
          
        public GenDTO deleteByPk(int id) {
            String source = "student--------->Delete ";
            System.out.println(source + "Invoke");
            GenDTO gdto = null;

            String sql = "DELETE FROM student WHERE id=?";

            try (Connection con = dbConnection.getConnection();
                 PreparedStatement psmt = con.prepareStatement(sql)) {

                System.out.println(source + "by primary key ");
                System.out.println(source + "sql=" + sql);

                psmt.setInt(1, id);
                System.out.println(source + "data set");

                int i = psmt.executeUpdate();

                if (i == 0) {
                    System.out.println(source + "record is not found");
                    gdto = new GenDTO(false, "Record is not found for given id", null);
                } else {
                    System.out.println(source + "Record is deleted successfully");
                    gdto = new GenDTO(true, "record deleted", null);
                }

            } catch (ClassNotFoundException | SQLException ex) {
                ex.printStackTrace();
                gdto = new GenDTO(false, ex.getMessage(), ex);
            }

            return gdto;
        }

//        


}
