package com.librarymanagementsystem.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.librarymanagementsystem.DTO.BookDto;
import com.librarymanagementsystem.DTO.GenDTO;

import com.librarymanagementsystem.db.dbConnection;
import com.librarymanagementsystem.entity.Book;
import com.librarymanagementsystem.entity.Lend;

public class BookDao {

	// ----------------------Insert Method ----------------------------

	public BookDto registerBook(Book book) {
		BookDto bDto = null;

		String sql = "insert into book (bName,author,publisher,isbn,category,noofcopy)values(?,?,?,?,?,?)";

		try (Connection con = dbConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, book.getName());
			ps.setString(2, book.getAuthor());
			ps.setString(3, book.getPublisher());
			ps.setString(4, book.getIsbn());
			ps.setString(5, book.getCategory());
			ps.setInt(6, book.getNoOfCopy());

			ps.executeUpdate();

		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();

		}

		return bDto;
	}

	// ------------------SELECT ALL METHOD--------------------

	public List<Book> getAllBook() {
		List<Book> list = new ArrayList<Book>();
		Connection con = null;

		try {

			con = dbConnection.getConnection();
			String sql = "SELECT * FROM book ORDER BY id DESC";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Book b = new Book();
				b.setId(rs.getInt("id"));
				b.setName(rs.getString("bName"));
				b.setAuthor(rs.getString("author"));
				b.setPublisher(rs.getString("publisher"));
				b.setIsbn(rs.getString("isbn"));
				b.setCategory(rs.getString("category"));
				b.setNoOfCopy(rs.getInt("noofcopy"));

				list.add(b);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {

			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}

	// ---------------- UPDATE METHOD ------------------------

	public GenDTO updateByPk(int id, Book book) {
		String source = "book------------>Update ";
		GenDTO gdto = null;
		String sql = "UPDATE book SET bName=?, author=?, publisher=?, isbn=?, category=?, noofcopy=? WHERE id=?";

		try (Connection con = dbConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, book.getName());
			ps.setString(2, book.getAuthor());
			ps.setString(3, book.getPublisher());
			ps.setString(4, book.getIsbn());
			ps.setString(5, book.getCategory());
			ps.setInt(6, book.getNoOfCopy());
			ps.setInt(7, id);

			int rowsAffected = ps.executeUpdate();

			if (rowsAffected == 0) {
				System.out.println(source + "Record not found for given id");
				gdto = new GenDTO(false, "Record not found", null);
			} else {
				System.out.println(source + "Record updated successfully");
				gdto = new GenDTO(true, "Record updated", null);
			}

		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
			gdto = new GenDTO(false, ex.getMessage(), ex);
		}

		return gdto;
	}

	// ---------------------- DELETE METHOD -------------------------------------

	public GenDTO deleteByPk(int id) {
		String source = "book--------->Delete ";
		GenDTO gdto = null;
		String sql = "DELETE FROM book WHERE id=?";

		try (Connection con = dbConnection.getConnection(); PreparedStatement psmt = con.prepareStatement(sql)) {

			psmt.setInt(1, id);
			int i = psmt.executeUpdate();
			if (i == 0) {
				System.out.println(source + "record is not found");
				gdto = new GenDTO(false, "Record is not found for given id", null);
			} else {
				System.out.println(source + "Record is deleted successfully");
				gdto = new GenDTO(true, "record deleted", null);
			}

		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
			gdto = new GenDTO(false, ex.getMessage(), ex);
		}

		return gdto;
	}

	// ------------------------------ GET ISSUED ---------------------------------------

	public static int getIssued(int id) {
		int issued = 0;
		try {
			Connection con = dbConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from book where id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				issued = rs.getInt("issued");
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return issued;
	}
	
	// --------------------------- CHECCK ISSUSED -------------------------------------
	
	public static boolean checkIssue(int id){
		boolean status=false;
		try{
			Connection con = dbConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from book where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				status=true;
			}
			con.close();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}

	// --------------------------- ISSUE BOOK --------------------------------------------

	public static int issueBook(Lend lend) {
		int id = lend.getId();
		boolean checkstatus = checkIssue(id);
		System.out.println("Check status: " + checkstatus);
		if (checkstatus) {
			int status = 0;
			try {
				Connection con = dbConnection.getConnection();
				PreparedStatement ps = con.prepareStatement("insert into lend values(?,?,?,?)");
				
				ps.setInt(1,lend.getId());
				ps.setInt(2, lend.getSid());
				ps.setDate(3, (Date) lend.getReturnDate());
 				
				java.sql.Date issue_date = new java.sql.Date(System.currentTimeMillis());
				ps.setDate(4, issue_date);

				status = ps.executeUpdate();
				if (status > 0) {
					PreparedStatement ps2 = con.prepareStatement("update book set issueddate=? where id=?");
					ps2.setInt(1, getIssued(id) + 1);
					ps2.setInt(2, id);
					status = ps2.executeUpdate();
				}
				con.close();

			} catch (Exception e) {
				System.out.println(e);
			}

			return status;
		} else {
			return 0;
		}
	}
	
	// ---------------------------- RETURNED BOOK  ---------------------------------------
	
	public static int returnBook(int id,int sid,LocalDate returnedDate){
		int status=0;
			try{
				Connection con = dbConnection.getConnection();
				PreparedStatement ps=con.prepareStatement("update issuebook set return status='yes' where id=? and sid=?");
				ps.setInt(1,id);
				ps.setInt(2,sid);
				
				status=ps.executeUpdate();
				if(status>0){
					PreparedStatement ps2=con.prepareStatement("update book set issue_date=? where id=?");
					ps2.setInt(1,getIssued(id)-1);
					ps2.setInt(2,id);
					status=ps2.executeUpdate();
				}
				con.close();
				
			}catch(Exception e){System.out.println(e);}
			
			return status;
	}
	
	
}
