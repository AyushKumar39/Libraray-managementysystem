package com.librarymanagementsystem.entity;

import java.util.Date;

public class Lend {

	private int lend_id;
	private int id;
	private int sid;
	private Date issueDate;
	private Date returnDate;
	
	
	
	
	public Lend(int lend_id, int id, int sid, Date issueDate, Date returnDate) {
		super();
		this.lend_id = lend_id;
		this.id = id;
		this.sid = sid;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
	}
	
	public Lend() {
		// TODO Auto-generated constructor stub
	}

	public Lend(int id2, int sid2) {
		this.id = id2;
		this.sid = sid2;	}

	public int getLend_id() {
		return lend_id;
	}
	public void setLend_id(int lend_id) {
		this.lend_id = lend_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	@Override
	public String toString() {
		return "lend [lend_id=" + lend_id + ", id=" + id + ", sid=" + sid + ", issueDate=" + issueDate + ", returnDate="
				+ returnDate + "]";
	}
	
	
	
	
}
