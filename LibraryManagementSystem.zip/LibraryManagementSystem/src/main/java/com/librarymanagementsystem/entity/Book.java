package com.librarymanagementsystem.entity;

public class Book {

	private int id;
	private String name;
	private String author;
	private String publisher;
	private String isbn;
	private String category;
	private int noOfCopy;

	public Book(String name, String author, String publisher, String isbn, String category, int noOfCopy) {
		super();

		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.isbn = isbn;
		this.category = category;
		this.noOfCopy = noOfCopy;
	}

	public Book(int id, String name, String author, String publisher, String isbn, String category, int noOfCopy) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.isbn = isbn;
		this.category = category;
		this.noOfCopy = noOfCopy;
	}

	public Book() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getNoOfCopy() {
		return noOfCopy;
	}

	public void setNoOfCopy(int noOfCopy) {
		this.noOfCopy = noOfCopy;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", author=" + author + ", publisher=" + publisher + ", isbn="
				+ isbn + ", category=" + category + ", noOfCopy=" + noOfCopy + "]";
	}

}
