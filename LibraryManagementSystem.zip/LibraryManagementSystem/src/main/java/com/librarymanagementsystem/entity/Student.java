package com.librarymanagementsystem.entity;

public class Student {
	private int id;
	private String name;
	private String studentId;
	private String password;
	private String email;
	private String mobNo;
	private String branch;
	
	 

	public Student(String name, String email,String paaword, String mobNo, String studentId, String branch) {
		super();
		this.name = name;
		this.studentId = studentId;
		this.password=paaword;
		this.email = email;
		this.mobNo = mobNo;
		this.branch = branch;
	}



	public Student() {
		// TODO Auto-generated constructor stub
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getStudentId() {
		return studentId;
	}



	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getMobNo() {
		return mobNo;
	}



	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}



	public String getBranch() {
		return branch;
	}



	public void setBranch(String branch) {
		this.branch = branch;
	}



	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", studentId=" + studentId + ", password=" + password
				+ ", email=" + email + ", mobNo=" + mobNo + ", branch=" + branch + "]";
	}
	
}
